import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import public_rpc_collect as c
d = os.path.join(os.path.dirname(c.__file__), "onchain")
for f in sorted(os.listdir(d)):
    if f.endswith(".json.gz"):
        print(f[:8], "refetched", c.refetch_errors(os.path.join(d, f)), c.calls, flush=True)
cfg = json.load(open(os.path.join(d, "config.json")))
c.SAMPLE = 60
pos = {w: v[:40] for w, v in cfg["pos_sigs"].items()}   # flagged bots: first 40 trades are enough
c.main(cfg["wallets"], pos)
print("done", c.calls, flush=True)
