"""Collect on-chain evidence for the repeated wallets from the FREE public Solana RPC
(api.mainnet-beta.solana.com). No Helius call is made anywhere in this script.
Per wallet: signature pages (<= MAX_PAGES), a fixed-seed random sample of recent transactions,
every transaction of the wallet's trades in the 12 winner pools, and the oldest transactions
(funding) when the history end is reachable. Raw results are saved gzip-compressed."""
import gzip, json, os, random, sys, time, urllib.request
RPC = "https://api.mainnet-beta.solana.com"
assert "helius" not in RPC
BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "onchain")
MAX_PAGES, SAMPLE, RPS = int(os.environ.get("MAX_PAGES", 30)), int(os.environ.get("SAMPLE", 120)), 3.0
_last = [0.0]; calls = {"n": 0, "429": 0}
def rpc(method, params):
    for attempt in range(8):
        wait = 1.0 / RPS - (time.time() - _last[0])
        if wait > 0: time.sleep(wait)
        _last[0] = time.time()
        req = urllib.request.Request(RPC, json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode(),
                                     {"Content-Type": "application/json"})
        try:
            calls["n"] += 1
            with urllib.request.urlopen(req, timeout=40) as r:
                d = json.load(r)
            if "error" in d:
                if d["error"].get("code") in (429, -32429): raise RuntimeError("429")
                return {"_error": d["error"]}
            return d.get("result")
        except Exception as e:
            if "429" in str(e): calls["429"] += 1
            time.sleep(min(30, 2 ** attempt))
    return {"_error": "retries exhausted"}
def gettx(sig):
    return rpc("getTransaction", [sig, {"maxSupportedTransactionVersion": 1, "encoding": "jsonParsed", "commitment": "finalized"}])
def main(wallets, pos_sigs):
    for w in wallets:
        path = os.path.join(OUT, f"{w}.json.gz")
        if os.path.exists(path): continue
        sigs, before, end_reached = [], None, False
        for _ in range(MAX_PAGES):
            p = {"limit": 1000}
            if before: p["before"] = before
            page = rpc("getSignaturesForAddress", [w, p])
            if not isinstance(page, list): break
            sigs += [{"s": x["signature"], "slot": x["slot"], "bt": x.get("blockTime"), "err": x.get("err") is not None} for x in page]
            if len(page) < 1000: end_reached = True; break
            before = page[-1]["signature"]
        rnd = random.Random(20261123)
        recent = [x for x in sigs if x["bt"] and x["bt"] >= sigs[0]["bt"] - 7 * 86400] if sigs else []
        sample = rnd.sample(recent, min(SAMPLE, len(recent)))
        txs = {}
        for x in sample: txs[x["s"]] = gettx(x["s"])
        for s in pos_sigs.get(w, []):
            if s not in txs: txs[s] = gettx(s)
        oldest = []
        if end_reached:
            for x in sigs[-3:]:
                oldest.append(x["s"]); txs.setdefault(x["s"], gettx(x["s"]))
        with gzip.open(path, "wt") as f:
            json.dump({"wallet": w, "signatures": sigs, "end_reached": end_reached, "pages": (len(sigs) + 999) // 1000,
                       "sample": [x["s"] for x in sample], "position_sigs": pos_sigs.get(w, []), "oldest": oldest,
                       "txs": txs, "collected_at": int(time.time()), "rpc": RPC}, f)
        print(w, "sigs", len(sigs), "end", end_reached, "txs", len(txs), "calls", calls, flush=True)
if __name__ == "__main__":
    cfg = json.load(open(sys.argv[1]))
    main(cfg["wallets"], cfg["pos_sigs"])
    print("done", calls)

def refetch_errors(path):
    """re-read transactions that failed (e.g. version-1 transactions rejected with version 0)"""
    with gzip.open(path, "rt") as f: D = json.load(f)
    n = 0
    for s, v in list(D["txs"].items()):
        if not v or (isinstance(v, dict) and "_error" in v):
            D["txs"][s] = gettx(s); n += 1
    with gzip.open(path, "wt") as f: json.dump(D, f)
    return n
