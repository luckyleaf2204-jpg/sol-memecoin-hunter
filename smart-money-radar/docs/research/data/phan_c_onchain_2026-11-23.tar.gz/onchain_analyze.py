"""Offline analysis of the public-RPC evidence (no network). Output: onchain/analysis.json"""
import bisect, gzip, json, math, os, statistics
from collections import Counter, defaultdict
B = os.path.dirname(os.path.abspath(__file__)); W_DIR = os.path.dirname(B)
WSOL = "So11111111111111111111111111111111111111112"; USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
MIHAO = "4CxjZyMNoF1p6eXHXHv1TWpS2X47CuUmLwtGe18spump"; QUOTES = {WSOL, USDC, MIHAO, "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"}
JITO = {"96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5", "HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe",
        "Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY", "ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49",
        "DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh", "ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt",
        "DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL", "3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT"}
NOISE_PROGRAMS = {"ComputeBudget111111111111111111111111111111", "11111111111111111111111111111111",
                  "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL", "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
                  "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb", "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr"}
sol = sorted((c[0], c[4]) for c in json.load(open(os.path.join(B, "sol_usd_hourly.json")))["data"]["attributes"]["ohlcv_list"])
_st = [a for a, _ in sol]
def su(bt): return sol[max(0, bisect.bisect_right(_st, bt) - 1)][1]
_mh = sorted((c[0], c[4]) for c in json.load(open(os.path.join(B, "mihao_usd_5m.json")))["data"]["attributes"]["ohlcv_list"])
_mt = [a for a, _ in _mh]
def mu(bt): return _mh[max(0, bisect.bisect_right(_mt, bt) - 1)][1]
def wilson(k, n, z=1.96):
    if not n: return (None, None)
    p = k / n; d = 1 + z * z / n; c = p + z * z / (2 * n); h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (round((c - h) / d, 3), round((c + h) / d, 3))
def deltas(tx, w):
    """wallet's SOL (lamports) and token deltas, signer flag, fee, programs, counterparties"""
    m = tx["meta"]; keys = tx["transaction"]["message"]["accountKeys"]
    idx = next((i for i, k in enumerate(keys) if k["pubkey"] == w), None)
    signer = idx is not None and keys[idx].get("signer", False)
    fee_payer = keys[0]["pubkey"]
    lam = (m["postBalances"][idx] - m["preBalances"][idx]) / 1e9 if idx is not None else 0.0
    tok = defaultdict(float); pre_bal, post_bal = defaultdict(float), defaultdict(float)
    for b in m.get("preTokenBalances") or []:
        if b.get("owner") == w: tok[b["mint"]] -= float(b["uiTokenAmount"]["uiAmountString"] or 0); pre_bal[b["mint"]] += float(b["uiTokenAmount"]["uiAmountString"] or 0)
    for b in m.get("postTokenBalances") or []:
        if b.get("owner") == w: tok[b["mint"]] += float(b["uiTokenAmount"]["uiAmountString"] or 0); post_bal[b["mint"]] += float(b["uiTokenAmount"]["uiAmountString"] or 0)
    progs = [i.get("programId") for i in tx["transaction"]["message"]["instructions"]]
    jito = 0.0; sol_in_from = []
    allins = list(tx["transaction"]["message"]["instructions"]) + [x for g in (m.get("innerInstructions") or []) for x in g["instructions"]]
    for ins in allins:
        p = ins.get("parsed")
        if isinstance(p, dict) and p.get("type") in ("transfer", "transferWithSeed") and ins.get("program") == "system":
            inf = p["info"]
            if inf.get("destination") in JITO and inf.get("source") == w: jito += inf["lamports"] / 1e9
            if inf.get("destination") == w and inf.get("source") != w: sol_in_from.append((inf.get("source"), inf["lamports"] / 1e9))
    return {"signer": signer, "fee_payer": fee_payer == w, "lamports": lam, "tok": {k: v for k, v in tok.items() if abs(v) > 0},
            "pre": dict(pre_bal), "post": dict(post_bal), "fee": m["fee"] / 1e9 if fee_payer == w else 0.0, "err": m.get("err") is not None,
            "programs": [p for p in progs if p not in NOISE_PROGRAMS], "jito": jito, "sol_in_from": sol_in_from,
            "keys": {k["pubkey"] for k in keys}}
def classify(d):
    if d["err"]: return "failed"
    nonq = {k: v for k, v in d["tok"].items() if k not in QUOTES}
    q = d["lamports"] + d["tok"].get(WSOL, 0) + d["tok"].get(USDC, 0) / 100 + d["tok"].get(MIHAO, 0) / 1e4
    if d["signer"]:
        ups = [v for v in nonq.values() if v > 0]; downs = [v for v in nonq.values() if v < 0]
        if (ups and (q < -0.0005 or downs)) or (downs and (q > 0 or ups)): return "swap"
        if nonq or abs(d["lamports"]) > 0.00001 + d["fee"] + d["jito"]: return "transfer_or_other_signed"
        return "other_signed"
    if nonq and all(v > 0 for v in nonq.values()): return "incoming_token_not_signed"
    if d["lamports"] > 0: return "incoming_sol_not_signed"
    return "other_not_signed"
def main():
    rep = json.load(open(os.path.join(B, "phase1b_result.json")))["repeated"]
    rk = json.load(open(os.path.join(W_DIR, "ranking.json")))
    zones = {}; trades_by = defaultdict(list); quote_of = {}
    for f in os.listdir(os.path.join(B, "trades")):
        d = json.load(gzip.open(os.path.join(B, "trades", f))); zones[d["mint"]] = d["zone"]
        for t in d["trades"]:
            trades_by[(t["wallet"], d["mint"])].append(t)
    for l in open(os.path.join(B, "pool_quotes.txt")):
        s = l.split()
        if len(s) > 2: quote_of[s[0]] = s[2]
    out = {}
    all_rep = set(rep)
    for w, r in rep.items():
        p = os.path.join(B, "onchain", f"{w}.json.gz")
        if not os.path.exists(p): continue
        D = json.load(gzip.open(p)); txs = D["txs"]; sigs = D["signatures"]
        bts = [s["bt"] for s in sigs if s["bt"]]
        span = (max(bts) - min(bts)) / 86400 if len(bts) > 1 else None
        per_day_all = len(sigs) / span if span else None
        # sample classification
        signer_ctr = Counter(); cls = Counter(); swap_bts, mints_sw, jito_n, progs = [], set(), 0, Counter(); rel = Counter()
        for s in D["sample"]:
            tx = txs.get(s)
            if not tx or not isinstance(tx, dict) or "_error" in tx: cls["unavailable"] += 1; continue
            d = deltas(tx, w); c = classify(d); cls[c] += 1
            if c == "swap":
                swap_bts.append(tx.get("blockTime")); mints_sw |= {k for k in d["tok"] if k not in QUOTES}
                jito_n += d["jito"] > 0; progs.update(d["programs"])
            signers = {k["pubkey"] for k in tx["transaction"]["message"]["accountKeys"] if k.get("signer")}
            for o in d["keys"] & all_rep - {w}:
                rel[(o, "signed_by_pair" if signers & {w, o} else "third_party_tx")] += 1
            for sg in signers - {w}: signer_ctr[sg] += 1
        n = sum(v for k, v in cls.items() if k != "unavailable")
        sample_bts = [s["bt"] for s in sigs if s["s"] in set(D["sample"]) and s["bt"]]
        recent = [s for s in sigs if s["bt"] and s["bt"] >= sigs[0]["bt"] - 7 * 86400]
        rs = (max(s["bt"] for s in recent) - min(s["bt"] for s in recent)) / 86400 if len(recent) > 1 else None
        recent_per_day = len(recent) / max(rs, 1 / 24) if rs is not None else None
        k = cls["swap"]; lo, hi = wilson(k, n)
        sw_day = {"point": round(k / n * recent_per_day, 1) if n and recent_per_day else None,
                  "lo95": round(lo * recent_per_day, 1) if lo is not None and recent_per_day else None,
                  "hi95": round(hi * recent_per_day, 1) if hi is not None and recent_per_day else None}
        sb = sorted(x for x in swap_bts if x)
        # positions verified on chain
        positions = []
        for pz in r["positions"]:
            m = pz["mint"]; tl = sorted(trades_by[(w, m)], key=lambda t: (t["slot"], t["bt"]))
            q = quote_of.get(m, WSOL)
            vt = []; ok = True; tb = ts = 0.0; net_q_sol = 0.0; fees = 0.0; jt = 0.0
            first_pre = last_post = None
            for t in tl:
                tx = txs.get(t["signature"])
                if not tx or "_error" in tx: ok = False; vt.append({"sig": t["signature"], "verified": False, "why": "tx unavailable"}); continue
                d = deltas(tx, w); dm = d["tok"].get(m, 0.0)
                match = d["signer"] and abs(abs(dm) - t["tok"]) <= 0.01 * t["tok"] and ((dm > 0) == (t["tx_type"] == "buy"))
                if q == WSOL: qd = d["lamports"] + d["tok"].get(WSOL, 0.0)
                elif q == USDC: qd = d["lamports"] + d["tok"].get(WSOL, 0.0) + d["tok"].get(USDC, 0.0) / su(tx["blockTime"])
                else: qd = d["lamports"] + d["tok"].get(WSOL, 0.0) + d["tok"].get(MIHAO, 0.0) * mu(tx["blockTime"]) / su(tx["blockTime"])
                net_q_sol += qd; fees += d["fee"]; jt += d["jito"]
                if first_pre is None: first_pre = d["pre"].get(m, 0.0)
                last_post = d["post"].get(m, 0.0)
                if t["tx_type"] == "buy": tb += abs(dm)
                else: ts += abs(dm)
                ok &= bool(match)
                vt.append({"sig": t["signature"], "type": t["tx_type"], "bt": t["bt"], "decoded_tok": t["tok"], "chain_tok": round(dm, 6),
                           "decoded_quote": t["sol"], "chain_net_sol_equiv": round(qd, 6), "signer": d["signer"], "fee": d["fee"],
                           "jito_tip": d["jito"], "verified": bool(match)})
            closed = last_post is not None and last_post <= 0.001 * max(tb, 1)
            opened_in_window = first_pre is not None and first_pre <= 0.001 * max(tb, 1)
            pnl_ok = ok and closed and opened_in_window
            peak = rk.get(m, {})
            fb = min((t for t in tl if t["tx_type"] == "buy"), key=lambda t: t["bt"], default=None)
            sells = [t for t in tl if t["tx_type"] == "sell"]
            positions.append({"mint": m, "quote": {WSOL: "SOL", USDC: "USDC", MIHAO: "mihao"}.get(q, q), "trades": len(tl),
                              "buys": sum(1 for t in tl if t["tx_type"] == "buy"), "sells": len(sells),
                              "first_buy_bt": fb["bt"] if fb else None, "first_buy_mc_usd": pz["first_buy_mc_usd"],
                              "peak_mc_usd": peak.get("peak_mc_usd"), "peak_at": peak.get("peak_hour"),
                              "hours_before_peak": round((peak["peak_hour"] - fb["bt"]) / 3600, 1) if fb and peak.get("peak_hour") else None,
                              "last_sell_bt": sells[-1]["bt"] if sells else None,
                              "hold_minutes": round((sells[-1]["bt"] - fb["bt"]) / 60, 1) if sells and fb else None,
                              "all_txs_verified": ok, "tokens_before_first_trade": first_pre, "tokens_after_last_trade": last_post,
                              "closed_in_data": closed, "opened_in_data": opened_in_window,
                              "pnl_verifiable": pnl_ok, "pnl_sol_after_fees": round(net_q_sol, 4) if pnl_ok else None,
                              "net_sol_flow_observed": round(net_q_sol, 4), "fees_sol": round(fees, 6), "jito_tips_sol": round(jt, 6),
                              "txs": vt})
        # funding
        funding = None
        if D["end_reached"]:
            srcs = []
            for s in reversed(D["oldest"]):
                tx = txs.get(s)
                if tx and "_error" not in tx:
                    d = deltas(tx, w); srcs += [{"sig": s, "bt": tx.get("blockTime"), "from": a, "sol": b} for a, b in d["sol_in_from"]]
            funding = {"first_tx_bt": sigs[-1]["bt"], "first_sig": sigs[-1]["s"], "sources": srcs}
        out[w] = {"tokens": r["tokens"], "bot_flag_on_other_token": r["bot_flag_on_other_token"],
                  "signatures_read": len(sigs), "pages": D["pages"], "history_end_reached": D["end_reached"],
                  "first_seen_bt": sigs[-1]["bt"] if sigs else None, "span_days_read": round(span, 2) if span else None,
                  "all_tx_per_day": round(per_day_all, 1) if per_day_all else None,
                  "recent7d_tx_per_day": round(recent_per_day, 1) if recent_per_day else None,
                  "sample_size": n, "sample_classes": dict(cls), "swap_share_ci95": [lo, hi],
                  "real_swaps_per_day": sw_day, "distinct_tokens_swapped_in_sample": len(mints_sw),
                  "sample_swaps_with_jito_tip": jito_n, "swap_programs": progs.most_common(5),
                  "median_seconds_between_sampled_swaps": int(statistics.median([b - a for a, b in zip(sb, sb[1:])])) if len(sb) > 2 else None,
                  "shared_txs_with_other_repeated_wallets": {f"{a}:{b}": n for (a, b), n in rel.items()},
                  "other_signers_in_sample": signer_ctr.most_common(3), "funding": funding, "positions": positions}
    # same-slot / near co-trading between repeated wallets in pool data
    co = Counter()
    by_tok = defaultdict(list)
    for (w, m), tl in trades_by.items():
        if w in rep:
            for t in tl: by_tok[m].append((t["slot"], w, t["tx_type"]))
    for m, l in by_tok.items():
        for i, a in enumerate(l):
            for b in l[i + 1:]:
                if a[1] != b[1] and abs(a[0] - b[0]) <= 2 and a[2] == b[2]: co[tuple(sorted((a[1], b[1])))] += 1
    res = {"wallets": out, "co_trades_within_2_slots": {f"{a}|{b}": n for (a, b), n in co.items()}}
    json.dump(res, open(os.path.join(B, "onchain", "analysis.json"), "w"), indent=1, default=str)
    return res
if __name__ == "__main__":
    r = main()
    for w, v in r["wallets"].items():
        print(w[:8], v["tokens"], "sigs", v["signatures_read"], "end", v["history_end_reached"], "tx/d", v["recent7d_tx_per_day"],
              "cls", v["sample_classes"], "swaps/d", v["real_swaps_per_day"], "jito", v["sample_swaps_with_jito_tip"],
              "mints", v["distinct_tokens_swapped_in_sample"], "gap", v["median_seconds_between_sampled_swaps"])
        for p in v["positions"]:
            print("   ", p["mint"][:6], p["quote"], "b/s", p["buys"], p["sells"], "ver", p["all_txs_verified"], "open/closed", p["opened_in_data"], p["closed_in_data"],
                  "pnl", p["pnl_sol_after_fees"], "flow", p["net_sol_flow_observed"], "hbp", p["hours_before_peak"], "hold", p["hold_minutes"])
        print("   funding", v["funding"] and v["funding"]["sources"][:3], "rel", v["shared_txs_with_other_repeated_wallets"])
    print("co", r["co_trades_within_2_slots"])
