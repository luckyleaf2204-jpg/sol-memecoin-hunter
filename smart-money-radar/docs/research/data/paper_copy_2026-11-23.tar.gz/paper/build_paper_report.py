import json, gzip, sys, datetime as dt
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
R = json.load(open("report.json"))
f = lambda t: dt.datetime.fromtimestamp(t, dt.UTC).strftime("%d/%m/%Y %H:%M:%S") if t else ""
W = list(R["wallets"])
wb = Workbook(); ws = wb.active; ws.title = "Tong hop"
ws.append(["Ví", "Giao dịch đọc", "Swap ví tự ký", "Không do ví ký (spam/hộ/transfer vào)", "Giao dịch lỗi", "Tự ký khác (transfer...)",
           "Swap sàn khác (giá ước tính)", "Vị thế đóng mô phỏng (tín hiệu mua)", "Ví gốc: PnL on-chain sau phí (SOL)", "Ví gốc: win rate",
           "Ví gốc: vốn vào (SOL)", "Ví gốc: giữ lệnh trung vị (giây)", "Độ trễ (giây)", "Copy được", "Tỷ lệ bắt kịp",
           "Paper PnL sau phí + trượt giá (SOL)", "Vốn copy (SOL)", "Paper win rate", "ROI trung bình/lệnh", "Drawdown tối đa (SOL)",
           "Giá copy cao hơn giá ví (trung vị)", "Không copy được: nguyên nhân", "Sai số mô hình giá (trung vị / p90)"])
for w in W:
    v = R["wallets"][w]; c = v["counts"]; o = v["wallet_original"]; m = v.get("model_check") or {}
    for dl, x in v["delays"].items():
        ws.append([w, c["signatures"], c["signed_swaps"], c["not_signed"], c["failed"], c["signed_other"], c["other_venue_swaps"],
                   v["positions_closed"], o["pnl_sol_onchain"], o["win_rate"], o["sol_in"], o["median_hold_s"], int(dl), x["copied"],
                   x["catch_rate"], x["pnl_sol"], x["invested_sol"], x["win_rate"], x["avg_roi"], x["max_drawdown_sol"], x["median_chase"],
                   "; ".join(f"{k}: {n}" for k, n in x["not_copyable"].items()) or "–",
                   f"{m.get('median_abs_error')} / {m.get('p90_abs_error')} ({m.get('buys_checked')} lệnh)" if m.get("buys_checked") else "Không áp dụng (sàn khác: giá từ giao dịch thật kế tiếp)"])
ws2 = wb.create_sheet("Vi the")
ws2.append(["Ví", "Token", "Sàn", "Mở (UTC)", "Chữ ký mua đầu", "Chữ ký bán cuối", "Ví: lệnh mua/bán", "Ví: vốn (SOL)", "Ví: PnL on-chain (SOL)",
            "Ví: ROI", "Ví: giữ (giây)"] + [h.format(d) for d in (1, 3, 5, 10) for h in ("Trễ {}s: copy được", "Trễ {}s: giá cao hơn ví", "Trễ {}s: tác động giá", "Trễ {}s: paper PnL (SOL)", "Trễ {}s: ROI", "Trễ {}s: lý do / ghi chú")])
for w in W:
    d = json.load(gzip.open(f"{w}.json.gz"))
    for s in d["simulations"]:
        row = [w, s["mint"], {"curve": "pump.fun curve", "pumpswap": "PumpSwap", "other": "Sàn khác (Meteora/Raydium)"}.get(s["venue"], s["venue"]),
               f(s["open_bt"]), s["open_sig"], s["wallet"].get("close_sig"), f"{s['wallet']['buys']}/{s['wallet']['sells']}", s["wallet"]["sol_in"],
               s["wallet"]["net_sol_onchain"], s["wallet"].get("roi"), s["wallet"]["hold_s"]]
        for dl in ("1", "3", "5", "10"):
            r = s["delays"][dl]
            note = r.get("reason") or r.get("exit_note") or ("giá ước tính từ giao dịch thật kế tiếp" if s["venue"] == "other" else "")
            if s["venue"] == "other" and r.get("copyable") and not (r.get("entry_from_real_trade") and r.get("exit_data_complete")):
                note = "không có giao dịch thật trong cửa sổ: dùng giá của ví (kém tin cậy)"
            row += ["Có" if r.get("copyable") else "Không", r.get("chase"), r.get("impact"), r.get("pnl_sol"), r.get("roi"), note]
        ws2.append(row)
ws3 = wb.create_sheet("Theo doi truc tiep")
ws3.append(["Ví", "Chữ ký", "Slot", "Thời điểm khối (UTC)", "Thời điểm phát hiện (UTC)", "Độ trễ phát hiện (giây)", "Ví tự ký", "Swap"])
for line in open("live_detections.jsonl"):
    x = json.loads(line)
    ws3.append([x["wallet"], x["sig"], x["slot"], f(x["block_time"]), f(x["detected_at"]), x["detect_delay_s"], "Có" if x["signed"] else "Không",
                "; ".join(f"{e['side']} {e['venue']} {round(e['sol'], 4)} SOL" for e in x["swap"]) or "–"])
ws4 = wb.create_sheet("Gia dinh")
for k, v in R["sim"].items(): ws4.append([k, json.dumps(v)])
thin = Side(style="thin", color="999999")
for s in wb.worksheets:
    for c in s[1]:
        c.font = Font(name="Times New Roman", bold=True, size=11); c.fill = PatternFill("solid", fgColor="D9E1F2")
        c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    for row in s.iter_rows(min_row=2):
        for c in row: c.font = Font(name="Times New Roman", size=11)
    for row in s.iter_rows():
        for c in row: c.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for col in s.columns:
        s.column_dimensions[col[0].column_letter].width = min(46, max(11, max(len(str(c.value or "")) for c in col[:50]) * 0.9))
    s.freeze_panes = "B2"
wb.save(sys.argv[1]); print("ok")
