import json, datetime as dt, sys
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
M = json.load(open("merged.json")); S = json.load(open("onchain/summary.json"))
f = lambda t: dt.datetime.fromtimestamp(t, dt.UTC).strftime("%d/%m/%Y %H:%M") if t else ""
CLUSTER = {"8P2vQR4MNhDp1fzKyV9zw6QSAUkHaAsSZdYxkwBmr5nG": "Cụm A (cùng slot: 8P2v, E69v, 5HM9)", "E69vrqyfrPJEb7gCH4ocfkVoKineucutR4rD4sgYkh6t": "Cụm A",
           "5HM96vknB75wfoZZuHeUArTXooH9mRNgB88kHHcgigL": "Cụm A", "Gmjvdkz2C5oMnYVEQFefnnFavEy9Ae7TrLyR5nq3LXyK": "Cụm B (cùng slot: Gmjv, 6AZA)",
           "6AZAXbi3Cw2mFpy9EAEaYgULWjNG3w8YeaYA4qqfJvqN": "Cụm B", "Bup46FaXBi8zr39c3sVh89hSqiyewJr85o7cbUtX7xtD": "Cụm C (cùng slot: Bup4, Bvka)",
           "BvkazozQxwPvgBbaTHBZFJsrGqn6cRWQgQU6V1GtvKgr": "Cụm C", "HzKH3s8Kf7f7pgvJZx2V6TzhkdHbZDurG53rXj61BVLR": "Đi sau 3kxcF8wH (10/12 token, cách ~2 giây)",
           "3kxcF8wHKm4sEtnxjXXeUvNGeDjTmo47LgtSRg71YfG5": "Dẫn trước HzKH3s8K (10/12 token)"}
RANK = [  # (wallet, tier, verdict)
 ("BvtZeURZMcvvQVBr5k9jDT53E2xuFq2Da6d6RTDP7gM4", 1, "Đủ bằng chứng để theo dõi thử"),
 ("7Q8rvHKi1brA49epwVyinrqX6rMKZxZqW1FoUgpXTpTs", 1, "Đủ bằng chứng để theo dõi thử (tần suất cao)"),
 ("ArF3BG43u4xakKDGQmyzcaLuxzZcY1L6SC8K6Miy4maz", 1, "Đủ bằng chứng để theo dõi thử (lệnh nhỏ)"),
 ("3kxcF8wHKm4sEtnxjXXeUvNGeDjTmo47LgtSRg71YfG5", 1, "Đủ bằng chứng để theo dõi thử (giữ lệnh ngắn)"),
 ("B8bvkQ7UqykUXUkVSdxngFtFBnonHf4sJTEX7s3gwwmS", 2, "Tiềm năng, cần thêm dữ liệu"),
 ("HUcYnQCHCojCmWTEHWtNZkMUYoY1yekWJ7HU1Xu6rAdY", 2, "Tiềm năng, cần thêm dữ liệu"),
 ("8P2vQR4MNhDp1fzKyV9zw6QSAUkHaAsSZdYxkwBmr5nG", 2, "Tiềm năng, cần thêm dữ liệu (đại diện cụm A)"),
 ("Gmjvdkz2C5oMnYVEQFefnnFavEy9Ae7TrLyR5nq3LXyK", 2, "Tiềm năng, cần thêm dữ liệu (đại diện cụm B)"),
 ("DCgZR7U5ti6Y3UB2supWyy6msfmSNmT7pZsE9tkkJ6F8", 2, "Tiềm năng, khó copy (giữ lệnh 26 giây)"),
 ("2T5NgDDidkvhJQg8AHDi74uCFwgp25pYFMRZXBaCUNBH", 2, "Tiềm năng, cần thêm dữ liệu"),
 ("51XcBjxnhAPUrDPZkdef1kUK3TJwAwCsCPRkCVJhTUbV", 2, "Tiềm năng, cần thêm dữ liệu"),
 ("5d3jQcuUvsuHyZkhdp78FFqc7WogrzZpTtec1X9VNkuE", 2, "Tiềm năng, cần thêm dữ liệu"),
 ("A3W8psibkTUvjxs4LRscbnjux6TFDXdvD4m4GsGpQ2KJ", 2, "Tiềm năng, cần thêm dữ liệu"),
 ("7GPgfyK7YR1AJWL76Wi3snaVnUFc57vJ2xpRWoLh8czn", 2, "Tiềm năng, khó copy (giữ lệnh 28 giây, tip Jito)"),
]
def lb(w):
    r = M[w]; de, ko, st = r["dedge"] or {}, r["kol"] or {}, (r["st"] or [{}])[0]
    return {"Nguồn": ", ".join(r["sources"]), "Tên KOL": ko.get("name"),
            "KOLX PnL 7D (USD)": ko.get("pnl_7d_usd"), "KOLX PnL 30D (USD)": ko.get("pnl_30d_usd"), "KOLX WR 7D": ko.get("wr_7d"),
            "KOLX WR 30D": ko.get("wr_30d"), "KOLX giữ lệnh trung vị": ko.get("median_hold"), "KOLX token/90 ngày": ko.get("tokens_touched_90d"),
            "dEdge net SOL 15D": de.get("net_sol_15d"), "dEdge WR 15D": de.get("win_rate"), "dEdge lệnh đóng 15D": de.get("closed_trades"),
            "dEdge token 15D": de.get("tokens"), "dEdge copy check": de.get("copy_check"), "dEdge trạng thái": de.get("status"),
            "dEdge lợi nhuận/lệnh p10/median/p75 (%)": "/".join(str(de.get("return_spread", {}).get(k, "")) for k in ("p10", "median", "p75")) if de else None,
            "ST realized 30D": st.get("Realized"), "ST WR 30D": st.get("Win Rate"), "ST giao dịch 30D": st.get("Trades"), "ST token 30D": st.get("Tokens")}
def oc(w):
    v = S.get(w)
    if not v: return {}
    return {"OC giao dịch đọc": v["window_tx"], "OC tỷ lệ ví tự ký": v["signed_share"], "OC khung (ngày)": v["window_days"],
            "OC swap/ngày": v["swaps_per_day"], "OC giao dịch/ngày (1.000 chữ ký)": v["tx_per_day_all"],
            "OC vị thế đóng": v["closed_positions"], "OC thắng": v["wins"], "OC win rate": v["win_rate"],
            "OC PnL sau phí (SOL)": v["pnl_sol_after_fees"], "OC tỷ trọng lệnh lớn nhất": v["best_share"],
            "OC giữ lệnh trung vị (giây)": v["median_hold_s"], "OC tỷ lệ giữ < 60 giây": v["share_hold_lt_60s"],
            "OC vốn/lệnh trung vị (SOL)": v["median_buy_sol"], "OC phí + tip (SOL)": v["fees_sol"], "OC swap có tip Jito": v["jito_swaps"],
            "OC giao dịch cuối (UTC)": f(v["last_tx_bt"])}
wb = Workbook()
ws = wb.active; ws.title = "Xep hang"
rows = []
for i, (w, t, verdict) in enumerate(RANK, 1):
    rows.append({"Hạng": i, "Ví": w, "Nhóm": t, "Kết luận": verdict, "Phối hợp/cụm": CLUSTER.get(w, "Không phát hiện"), **lb(w), **oc(w)})
hdr = list(rows[0].keys()); ws.append(hdr)
for r in rows: ws.append([r.get(h) for h in hdr])
ws2 = wb.create_sheet("Kiem chung 42 vi")
h2 = ["Ví", "Phối hợp/cụm"] + list(oc(next(iter(S))).keys()); ws2.append(h2)
for w in S: ws2.append([w, CLUSTER.get(w, "")] + [oc(w).get(h) for h in h2[2:]])
ws3 = wb.create_sheet("Tat ca 335 vi")
h3 = ["Ví", "Lý do loại (theo số liệu leaderboard)"] + list(lb(next(iter(M))).keys()); ws3.append(h3)
for w, r in M.items(): ws3.append([w, "; ".join(r["excluded"]) or "Qua vòng lọc → kiểm chứng on-chain"] + [lb(w).get(h) for h in h3[2:]])
ws4 = wb.create_sheet("Vi the da dong")
ws4.append(["Ví", "Token", "Mở (UTC)", "Số lệnh mua", "Số lệnh bán", "Vốn mua (SOL)", "PnL sau phí (SOL)", "Phí (SOL)", "Tip Jito (SOL)", "Giữ (giây)", "Chữ ký mở", "Chữ ký đóng"])
for w, v in S.items():
    for p in v["positions"]:
        ws4.append([w, p["mint"], f(p["open_bt"]), p["buys"], p["sells"], p["buy_sol"], p["pnl_sol"], p["fees"], p["jito"], p["hold_s"], p["open_sig"], p["close_sig"]])
thin = Side(style="thin", color="999999")
for s in wb.worksheets:
    for c in s[1]:
        c.font = Font(name="Times New Roman", bold=True, size=11); c.fill = PatternFill("solid", fgColor="D9E1F2")
        c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
    for row in s.iter_rows(min_row=2):
        for c in row: c.font = Font(name="Times New Roman", size=11)
    for row in s.iter_rows():
        for c in row: c.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for col in s.columns:
        s.column_dimensions[col[0].column_letter].width = min(48, max(11, max(len(str(c.value or "")) for c in col[:60]) * 0.9))
    s.freeze_panes = "C2"
wb.save(sys.argv[1])
json.dump(rows, open("ranking_rows.json", "w"), indent=1, ensure_ascii=False, default=str)
for r in rows: print(r["Hạng"], r["Ví"][:8], r["Nguồn"], r.get("OC vị thế đóng"), r.get("OC win rate"), r.get("OC PnL sau phí (SOL)"), r.get("OC giữ lệnh trung vị (giây)"), r.get("OC swap/ngày"))
