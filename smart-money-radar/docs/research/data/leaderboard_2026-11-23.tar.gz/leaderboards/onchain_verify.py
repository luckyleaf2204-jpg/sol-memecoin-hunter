"""On-chain verification of leaderboard wallets through the FREE public Solana RPC (no Helius).
Per wallet: 1 page of signatures (activity rate), then the N most recent transactions in full
(contiguous window) -> signer check, swap classification, closed positions rebuilt from balance
changes, realized PnL after fees (SOL), win rate, hold time, Jito tips. Saves raw + summary."""
import gzip, json, os, statistics, sys
from collections import defaultdict
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "pumpswap"))
import public_rpc_collect as rpcmod          # noqa: E402  (public RPC only; asserts no helius URL)
from onchain_analyze import deltas, QUOTES, WSOL   # noqa: E402
N_TX = int(os.environ.get("N_TX", 120))
OUT = os.path.join(HERE, "onchain")
os.makedirs(OUT, exist_ok=True)


def collect(w):
    p = os.path.join(OUT, f"{w}.json.gz")
    if os.path.exists(p):
        return json.load(gzip.open(p))
    sigs = rpcmod.rpc("getSignaturesForAddress", [w, {"limit": 1000}])
    sigs = sigs if isinstance(sigs, list) else []
    txs = {}
    for s in sigs[:N_TX]:
        txs[s["signature"]] = rpcmod.gettx(s["signature"])
    D = {"wallet": w, "signatures": [{"s": x["signature"], "bt": x.get("blockTime"), "err": x.get("err") is not None} for x in sigs],
         "txs": txs}
    with gzip.open(p, "wt") as f:
        json.dump(D, f)
    return D


def analyze(D):
    w = D["wallet"]; sigs = D["signatures"]
    bts = [s["bt"] for s in sigs if s["bt"]]
    span = (max(bts) - min(bts)) / 86400 if len(bts) > 1 else None
    rows = []
    for s in sigs[:N_TX]:
        tx = D["txs"].get(s["s"])
        if not tx or not isinstance(tx, dict) or "_error" in tx:
            rows.append({"sig": s["s"], "bt": s["bt"], "kind": "unavailable"}); continue
        d = deltas(tx, w)
        nonq = {k: v for k, v in d["tok"].items() if k not in QUOTES}
        solq = d["lamports"] + d["tok"].get(WSOL, 0.0)
        kind = "failed" if d["err"] else ("not_signed" if not d["signer"] else "other_signed")
        if kind == "other_signed" and len(nonq) == 1:
            (m, v), = nonq.items()
            if v > 0 and solq < 0: kind = "buy"
            elif v < 0 and solq > 0: kind = "sell"
        elif kind == "other_signed" and len(nonq) > 1:
            kind = "multi_token"
        rows.append({"sig": s["s"], "bt": tx.get("blockTime"), "slot": tx.get("slot"), "kind": kind, "signer": d["signer"],
                     "mint": next(iter(nonq)) if len(nonq) == 1 else None, "tok": next(iter(nonq.values())) if len(nonq) == 1 else None,
                     "sol": round(solq, 9), "fee": d["fee"], "jito": d["jito"],
                     "pre": d["pre"].get(next(iter(nonq)), 0.0) if len(nonq) == 1 else None,
                     "post": d["post"].get(next(iter(nonq)), 0.0) if len(nonq) == 1 else None, "programs": d["programs"][:3]})
    rows.sort(key=lambda r: (r.get("bt") or 0, r.get("slot") or 0))
    # positions fully inside the window: first buy from a zero balance, last sell back to ~zero
    by = defaultdict(list)
    for r in rows:
        if r["kind"] in ("buy", "sell"): by[r["mint"]].append(r)
    closed, open_ = [], 0
    for m, rs in by.items():
        cur = None
        for r in rs:
            if r["kind"] == "buy" and (r["pre"] or 0) <= 1e-9 and cur is None:
                cur = {"mint": m, "txs": [r]}
            elif cur is not None:
                cur["txs"].append(r)
            if cur is not None and r["kind"] == "sell" and (r["post"] or 0) <= max(1e-6, 1e-4 * sum(x["tok"] for x in cur["txs"] if x["kind"] == "buy")):
                t = cur["txs"]
                closed.append({"mint": m, "buys": sum(1 for x in t if x["kind"] == "buy"), "sells": sum(1 for x in t if x["kind"] == "sell"),
                               "buy_sol": round(-sum(x["sol"] for x in t if x["kind"] == "buy"), 6),
                               "pnl_sol": round(sum(x["sol"] for x in t), 6), "fees": round(sum(x["fee"] for x in t), 6),
                               "jito": round(sum(x["jito"] for x in t), 6), "hold_s": t[-1]["bt"] - t[0]["bt"],
                               "open_sig": t[0]["sig"], "close_sig": t[-1]["sig"], "open_bt": t[0]["bt"]})
                cur = None
        if cur is not None: open_ += 1
    sw = [r for r in rows if r["kind"] in ("buy", "sell", "multi_token")]
    swb = [r["bt"] for r in sw if r.get("bt")]
    wspan = (max(swb) - min(swb)) / 86400 if len(swb) > 1 else None
    win = [c for c in closed if c["pnl_sol"] > 0]
    pn = [c["pnl_sol"] for c in closed]
    tot = sum(pn)
    holds = sorted(c["hold_s"] for c in closed)
    kinds = defaultdict(int)
    for r in rows: kinds[r["kind"]] += 1
    return {"wallet": w, "signatures_page": len(sigs), "tx_per_day_all": round(len(sigs) / span, 1) if span else None,
            "last_tx_bt": max(bts) if bts else None, "window_tx": len(rows), "kinds": dict(kinds),
            "signed_share": round(sum(1 for r in rows if r.get("signer")) / max(1, len(rows)), 3),
            "swaps_in_window": len(sw), "swaps_per_day": round(len(sw) / max(wspan, 1 / 24), 1) if wspan is not None else None,
            "window_days": round(wspan, 2) if wspan else None, "jito_swaps": sum(1 for r in sw if r["jito"] > 0),
            "closed_positions": len(closed), "open_positions_in_window": open_, "wins": len(win),
            "win_rate": round(len(win) / len(closed), 3) if closed else None, "pnl_sol_after_fees": round(tot, 4),
            "best_share": round(max(pn) / tot, 3) if tot > 0 and pn else None,
            "median_hold_s": holds[len(holds) // 2] if holds else None,
            "share_hold_lt_60s": round(sum(1 for h in holds if h < 60) / len(holds), 3) if holds else None,
            "median_buy_sol": round(statistics.median([c["buy_sol"] for c in closed]), 4) if closed else None,
            "fees_sol": round(sum(c["fees"] + c["jito"] for c in closed), 5), "positions": closed}


if __name__ == "__main__":
    wallets = json.load(open(sys.argv[1]))
    summ = {}
    for w in wallets:
        D = collect(w)
        summ[w] = analyze(D)
        s = summ[w]
        print(w[:8], "tx/d", s["tx_per_day_all"], "swaps/d", s["swaps_per_day"], "closed", s["closed_positions"], "wr", s["win_rate"],
              "pnl", s["pnl_sol_after_fees"], "hold", s["median_hold_s"], "calls", rpcmod.calls, flush=True)
        json.dump(summ, open(os.path.join(OUT, "summary.json"), "w"), indent=1)
    print("done", rpcmod.calls, flush=True)
