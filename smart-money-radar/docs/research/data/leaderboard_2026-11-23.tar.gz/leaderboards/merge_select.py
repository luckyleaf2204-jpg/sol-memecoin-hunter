"""Merge the three public sources, de-duplicate wallets and apply the selection rules (offline)."""
import json, re, collections
d = json.load(open("leaderboards.json"))
def num(s):
    if s is None: return None
    m = re.search(r"([\d.,]+)\s*([KMB]?)", str(s))
    return float(m.group(1).replace(",", "")) * {"": 1, "K": 1e3, "M": 1e6, "B": 1e9}[m.group(2)] if m else None
def pct(s):
    m = re.search(r"([\d.]+)%", str(s or "")); return float(m.group(1)) if m else None
def hs(s):
    m = re.search(r"([\d.]+)\s*(s|min|h|d)", s or ""); return float(m.group(1)) * {"s": 1, "min": 60, "h": 3600, "d": 86400}[m.group(2)] if m else None
def age_days(s):
    s = (s or "").replace("⏱", "").strip()
    m = re.search(r"(\d+)\s*(m|h|d)", s)
    if not m: return None
    return int(m.group(1)) * {"m": 1 / 1440, "h": 1 / 24, "d": 1}[m.group(2)]
W = collections.defaultdict(lambda: {"sources": [], "st": [], "dedge": None, "kol": None})
for r in d["solanatracker"]:
    W[r["wallet"]]["sources"].append("SolanaTracker-" + r["board"]); W[r["wallet"]]["st"].append(r)
for w, v in d["dedge"]["wallets"].items():
    W[w]["sources"].append("dEdge" + ("(bots)" if "/bots" in v["lists"] else "")); W[w]["dedge"] = v
for k in d["kolexplorer"]:
    for w in k["wallets"]:
        W[w]["sources"].append("KOLExplorer"); W[w]["kol"] = k
res = {}
for w, x in W.items():
    reasons = []
    st = x["st"][0] if x["st"] else None
    de = x["dedge"]; ko = x["kol"]
    if de and "/bots" in de["lists"]: reasons.append("dEdge xếp vào danh sách bot/sniper")
    if st:
        tr, tk = num(st.get("Trades")), num(st.get("Tokens"))
        if tk is not None and tk <= 5: reasons.append(f"chỉ {int(tk)} token trong 30D (cá voi/insider)")
        if tr is not None and tr > 3000: reasons.append(f"{int(tr)} giao dịch/30D (>100/ngày: bot/MM)")
        if age_days(st.get("last_active")) and age_days(st.get("last_active")) > 3: reasons.append(f"không hoạt động {st.get('last_active')}")
        if (pct(st.get("Win Rate")) or 0) < 45: reasons.append(f"win rate 30D {st.get('Win Rate')} < 45%")
    if ko:
        h = hs(ko["median_hold"]); tt = num(ko["tokens_touched_90d"])
        if not ((ko["pnl_7d_usd"] or 0) > 0 and (ko["pnl_30d_usd"] or 0) > 0): reasons.append("PnL 7D hoặc 30D không dương")
        if h is not None and h < 45: reasons.append(f"giữ lệnh trung vị {ko['median_hold']} (< 45 giây: không copy kịp)")
        if tt and tt > 2700: reasons.append(f"{int(tt)} token/90 ngày (> 30 token/ngày)")
        if (pct(ko["wr_30d"]) or 0) < 45: reasons.append(f"win rate 30D {ko['wr_30d']} < 45%")
        if age_days(ko["last_trade"]) and age_days(ko["last_trade"]) > 3: reasons.append(f"lệnh cuối {ko['last_trade'].strip()}")
    if de and "/bots" not in de["lists"]:
        if (de.get("net_sol_15d") or 0) <= 0: reasons.append("net SOL 15D không dương")
        if de.get("copy_check") not in ("pass",): reasons.append(f"dEdge copy check: {de.get('copy_check')}")
        if int(de.get("closed_trades") or 0) < 30: reasons.append(f"chỉ {de.get('closed_trades')} lệnh đóng/15D")
        if (de.get("status") or "") != "ACTIVE": reasons.append(f"trạng thái {de.get('status')}")
    res[w] = {"sources": sorted(set(x["sources"])), "excluded": reasons, "st": x["st"], "dedge": de,
              "kol": {k: v for k, v in ko.items() if k != "wallets"} if ko else None}
sel = {w: r for w, r in res.items() if not r["excluded"]}
json.dump(res, open("merged.json", "w"), indent=1, ensure_ascii=False)
print("unique", len(res), "selected for on-chain check", len(sel))
c = collections.Counter(re.sub(r"[\d.,]+", "N", e.split("(")[0]).strip() for r in res.values() for e in r["excluded"])
for k, v in c.most_common(20): print(v, k)
for w, r in sel.items():
    de, ko, st = r["dedge"], r["kol"], r["st"]
    print(w, r["sources"], (ko or {}).get("slug"), (ko or {}).get("pnl_7d_usd"), (ko or {}).get("pnl_30d_usd"), (ko or {}).get("wr_30d"), (ko or {}).get("median_hold"),
          (de or {}).get("net_sol_15d"), (de or {}).get("win_rate"), (de or {}).get("closed_trades"), [(s.get("Realized"), s.get("Trades"), s.get("Tokens")) for s in st][:1])
